package com.ecommerce.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ecommerce.beans.Quote;

@RestController
@RequestMapping("/")
public class MainController {
    private final String apiUrl = "https://type.fit/api/quotes";

    @GetMapping
    public Quote getQuotes() {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(apiUrl, Quote.class);
    }
}
